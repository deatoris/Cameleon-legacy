#======================================
#Cam�l�on Creator & Population 
#
#Copyright 2012 O. Cugnon de S�vricourt & V. Tariel
#
#This software is under the MIT license :
#Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the Software), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
#The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
#THE SOFTWARE IS PROVIDED AS IS, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

#More informations can be found here: http://www.shinoe.org/cameleon
#======================================
!include(configuration.pri)
#CAMELEON INCLUDES
!include($${SOURCEPATH}/machine/client/includeclient.pri)
!include($${SOURCEPATH}/machine/kernel/includekernel.pri)
!include($${SOURCEPATH}/machine/ide/includeide.pri)

#CAMELEON SOURCES
!include($${SOURCEPATH}/machine/client/client.pri)
!include($${SOURCEPATH}/machine/kernel/kernel.pri)
!include($${SOURCEPATH}/machine/ide/ide.pri)

#LIB SOURCES
!include($${SOURCEPATH}/machine/scd/includescd.pri)
!include($${SOURCEPATH}/machine/scd/scd.pri)
#!include($${SOURCEPATH}/dictionary/population/population.pri)
!include($${SOURCEPATH}/dictionary/connectivity/connectivity.pri)
!include($${SOURCEPATH}/dictionary/customplot/QCustomPlotBindingCameleon.pri)


!include($${SOURCEPATH}/dictionary/population/population.pri)


