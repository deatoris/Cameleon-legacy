##########################################
Cam�l�on & Population are open source independant software

Cam�l�on Creator v2.0.6
Population library v1.0.2
Cam�l�on Machine v2.0.6

Copyright Olivier Cugnon de S�vricourt et Vincent Tariel - 2012
##########################################

1) Description
This directory contain Cam�l�on version 2.0.6 & Population version 1.0.2.

2) Cam�l�on & Population
Cam�l�on has been created by Olivier Cugnon de S�vricourt & Vincent Tariel. 
Population has been created by Vincent Tariel.
Cam�l�on has been invented by Olivier Cugnon de S�vricourt & Vincent Tariel (http://arxiv.org/abs/1110.4802)

3) Cam�l�on dev kit
The dev kit is a vailable using QT SDK & the generator project in project/devkit/generator (this is a Cam�l�on *.cm project file).

4) Source code
If you need to have access to the Population source code, please go to Population web site (http://www.population-image.fr).
If you need to have access to the Cam�l�on source code, please send-us your request describing your open source project from here: http://www.shinoe.org/cameleon/contact/.
The source code will be publicly available as soon as we can!

5) Third Party Dictionaries
The lib directory contain the first external Cam�l�on dictionary based on QCustomPlot (see here: http://www.workslikeclockwork.com). This dictionary is activated by default.

6) Linux Launch
On Linux/Unix, you need to install qtcreator and glut:
	sudo apt-get install qtcreator
	sudo apt-get install freeglut3
You should now be able to execute the file as normal. You can do this from the command line by typing:
	./cameleon.sh.

7) Windows Launch
Double click on cameleon.bat at the root directory
